
class RunSample {

  public static void main(String args[]) {
    new internetics.Sample("y2015g44").setVisible(true);
  }
}

